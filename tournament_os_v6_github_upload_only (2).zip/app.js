(function () {
  'use strict';

  const CONFIG = {
    useRealSupabase: !!window.__USE_REAL_SUPABASE__,
    supabaseUrl: window.__SUPABASE_URL__ || '',
    supabaseAnonKey: window.__SUPABASE_ANON_KEY__ || ''
  };

  const DEMO_DB = {
    profiles: [
      { id: 'profile_anna', display_name: 'Anna Petrova', city: 'Riga', level: 'B+', role: 'player' },
      { id: 'profile_mark', display_name: 'Mark Johnson', city: 'Jurmala', level: 'A', role: 'player' },
      { id: 'profile_oleg', display_name: 'Oleg Sokolov', city: 'Riga', level: 'B', role: 'player' },
      { id: 'profile_kate', display_name: 'Kate Ozola', city: 'Riga', level: 'B', role: 'player' }
    ],
    clubs: [
      { id: 'club_riga', name: 'Riga Padel Club', city: 'Riga' },
      { id: 'club_jurmala', name: 'Jurmala Padel Center', city: 'Jurmala' }
    ],
    tournaments: [
      { id: 'tour_live_1', club_id: 'club_riga', name: 'Spring Open', description: 'Player-first weekend tournament.', format_code: 'Americano', tournament_status: 'live', start_at: '2026-04-05T09:00:00Z', max_players: 16, venue_name: 'Riga Padel Club' },
      { id: 'tour_joined_1', club_id: 'club_jurmala', name: 'Baltic Mix Cup', description: 'Registration closed. Schedule coming soon.', format_code: 'Groups', tournament_status: 'open', start_at: '2026-04-12T10:00:00Z', max_players: 12, venue_name: 'Jurmala Padel Center' },
      { id: 'tour_new_1', club_id: 'club_riga', name: 'City Night Padel', description: 'Evening event with short match slots.', format_code: 'Mexicano', tournament_status: 'open', start_at: '2026-04-16T18:30:00Z', max_players: 16, venue_name: 'Riga Padel Club' },
      { id: 'tour_new_2', club_id: 'club_jurmala', name: 'Weekend Ladder', description: 'Short ladder format for active players.', format_code: 'Ladder', tournament_status: 'open', start_at: '2026-04-20T09:30:00Z', max_players: 24, venue_name: 'Jurmala Padel Center' },
      { id: 'tour_hist_1', club_id: 'club_riga', name: 'March Club Series', description: 'Finished event.', format_code: 'Groups', tournament_status: 'finished', start_at: '2026-03-12T09:00:00Z', max_players: 16, venue_name: 'Riga Padel Club' }
    ],
    tournament_players: [
      { id: 'tp1', tournament_id: 'tour_live_1', profile_id: 'profile_anna', participation_status: 'joined' },
      { id: 'tp2', tournament_id: 'tour_live_1', profile_id: 'profile_mark', participation_status: 'joined' },
      { id: 'tp3', tournament_id: 'tour_live_1', profile_id: 'profile_oleg', participation_status: 'joined' },
      { id: 'tp4', tournament_id: 'tour_live_1', profile_id: 'profile_kate', participation_status: 'joined' },
      { id: 'tp5', tournament_id: 'tour_joined_1', profile_id: 'profile_anna', participation_status: 'joined' },
      { id: 'tp6', tournament_id: 'tour_hist_1', profile_id: 'profile_anna', participation_status: 'joined', final_rank: 3 }
    ],
    matches: [
      { id: 'm1', tournament_id: 'tour_live_1', round_no: 1, court_label: 'Court 1', scheduled_at: '2026-04-05T09:30:00Z', match_status: 'scheduled', result_status: 'missing', notes: '' },
      { id: 'm2', tournament_id: 'tour_live_1', round_no: 2, court_label: 'Court 2', scheduled_at: '2026-04-05T11:00:00Z', match_status: 'scheduled', result_status: 'missing', notes: '' }
    ],
    match_players: [
      { id: 'mp1', match_id: 'm1', tournament_player_id: 'tp1', seat_no: 1, team_no: 1 },
      { id: 'mp2', match_id: 'm1', tournament_player_id: 'tp2', seat_no: 2, team_no: 1 },
      { id: 'mp3', match_id: 'm1', tournament_player_id: 'tp3', seat_no: 3, team_no: 2 },
      { id: 'mp4', match_id: 'm1', tournament_player_id: 'tp4', seat_no: 4, team_no: 2 },
      { id: 'mp5', match_id: 'm2', tournament_player_id: 'tp1', seat_no: 1, team_no: 2 },
      { id: 'mp6', match_id: 'm2', tournament_player_id: 'tp4', seat_no: 2, team_no: 2 },
      { id: 'mp7', match_id: 'm2', tournament_player_id: 'tp2', seat_no: 3, team_no: 1 },
      { id: 'mp8', match_id: 'm2', tournament_player_id: 'tp3', seat_no: 4, team_no: 1 }
    ],
    match_results: [],
    standings_entries: [
      { id: 's1', tournament_id: 'tour_live_1', profile_id: 'profile_anna', played: 0, won: 0, lost: 0, points: 0, diff: 0, rank_no: 1 },
      { id: 's2', tournament_id: 'tour_live_1', profile_id: 'profile_mark', played: 0, won: 0, lost: 0, points: 0, diff: 0, rank_no: 2 },
      { id: 's3', tournament_id: 'tour_live_1', profile_id: 'profile_oleg', played: 0, won: 0, lost: 0, points: 0, diff: 0, rank_no: 3 },
      { id: 's4', tournament_id: 'tour_live_1', profile_id: 'profile_kate', played: 0, won: 0, lost: 0, points: 0, diff: 0, rank_no: 4 }
    ],
    activity_log: [
      { id: 1, action_code: 'join', entity_id: 'tour_joined_1', actor_profile_id: 'profile_anna', created_at: '2026-04-01T09:12:00Z', payload: { message: 'Joined Baltic Mix Cup' } },
      { id: 2, action_code: 'launch', entity_id: 'tour_live_1', actor_profile_id: 'profile_mark', created_at: '2026-04-02T07:20:00Z', payload: { message: 'Spring Open moved to LIVE' } }
    ]
  };

  const DEMO_KEY = 'tournament_os_v6_fast_db';
  const SESSION_KEY = 'tournament_os_v6_fast_session';

  const state = {
    route: { view: 'home', tournamentId: null, tab: 'overview' },
    ui: { homeSearch: '', matchFilter: 'all' },
    sheet: null,
    toastTimer: null,
    db: loadDb(),
    session: loadSession(),
    adapter: null,
    history: [{ view: 'home', tournamentId: null, tab: 'overview' }]
  };

  const $ = (selector) => document.querySelector(selector);
  const root = $('#appRoot');
  const toastRoot = $('#toastRoot');
  const sheetRoot = $('#sheetRoot');

  function clone(data) { return JSON.parse(JSON.stringify(data)); }
  function loadDb() {
    try {
      const raw = localStorage.getItem(DEMO_KEY);
      return raw ? JSON.parse(raw) : clone(DEMO_DB);
    } catch { return clone(DEMO_DB); }
  }
  function saveDb() { localStorage.setItem(DEMO_KEY, JSON.stringify(state.db)); }
  function loadSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      return raw ? JSON.parse(raw) : { profileId: 'profile_anna', email: 'anna@demo.test' };
    } catch { return { profileId: 'profile_anna', email: 'anna@demo.test' }; }
  }
  function saveSession() { localStorage.setItem(SESSION_KEY, JSON.stringify(state.session)); }
  function byId(rows, id) { return rows.find((r) => r.id === id); }
  function formatDate(dateString) {
    return new Date(dateString).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  }
  function initials(name) { return name.split(' ').map((x) => x[0]).slice(0,2).join('').toUpperCase(); }
  function esc(text) {
    return String(text ?? '').replace(/[&<>'"]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  }
  function pushRoute(next) {
    state.history.push(clone(next));
    state.route = next;
  }
  function showToast(text) {
    toastRoot.innerHTML = `<div class="toast">${esc(text)}</div>`;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => { toastRoot.innerHTML = ''; }, 2200);
  }

  function currentProfile() { return byId(state.db.profiles, state.session.profileId); }
  function currentMembership(tournamentId) {
    return state.db.tournament_players.find((p) => p.tournament_id === tournamentId && p.profile_id === state.session.profileId && p.participation_status !== 'withdrawn');
  }

  function tournamentCard(t) {
    const membership = currentMembership(t.id);
    const status = t.tournament_status === 'live' ? 'live' : membership ? membership.participation_status : 'open';
    return {
      ...t,
      status,
      club: byId(state.db.clubs, t.club_id),
      joinedCount: state.db.tournament_players.filter((p) => p.tournament_id === t.id && p.participation_status === 'joined').length
    };
  }

  function computeHome() {
    const cards = state.db.tournaments.map(tournamentCard);
    const search = state.ui.homeSearch.trim().toLowerCase();
    const filtered = cards.filter((c) => !search || `${c.name} ${c.venue_name} ${c.format_code}`.toLowerCase().includes(search));
    const my = filtered.filter((c) => ['live','joined','waitlist'].includes(c.status) && c.tournament_status !== 'finished');
    const available = filtered.filter((c) => !currentMembership(c.id) && c.tournament_status === 'open');
    const history = cards.filter((c) => c.tournament_status === 'finished' && currentMembership(c.id));
    return { my, available, history };
  }

  function computeMatches() {
    return state.db.matches
      .filter((match) => {
        const rows = state.db.match_players.filter((mp) => mp.match_id === match.id);
        return rows.some((row) => byId(state.db.tournament_players, row.tournament_player_id)?.profile_id === state.session.profileId);
      })
      .map((match) => {
        const players = state.db.match_players.filter((mp) => mp.match_id === match.id).map((mp) => {
          const tp = byId(state.db.tournament_players, mp.tournament_player_id);
          const profile = byId(state.db.profiles, tp.profile_id);
          return { ...mp, profile, name: profile.display_name };
        });
        const team1 = players.filter((p) => p.team_no === 1).map((p) => p.name).join(' / ');
        const team2 = players.filter((p) => p.team_no === 2).map((p) => p.name).join(' / ');
        const result = state.db.match_results.find((r) => r.match_id === match.id);
        return {
          ...match,
          tournament: byId(state.db.tournaments, match.tournament_id),
          team1, team2,
          score: result?.score_display || 'Pending',
          submittedBy: result ? byId(state.db.profiles, result.submitted_by_profile_id)?.display_name : null
        };
      })
      .filter((match) => state.ui.matchFilter === 'all' || match.result_status === state.ui.matchFilter);
  }

  function computeTournament(tournamentId) {
    const tournament = tournamentCard(byId(state.db.tournaments, tournamentId));
    const matches = computeMatches().filter((m) => m.tournament_id === tournamentId);
    const standings = state.db.standings_entries
      .filter((s) => s.tournament_id === tournamentId)
      .map((s) => ({ ...s, profile: byId(state.db.profiles, s.profile_id) }))
      .sort((a, b) => b.points - a.points || b.diff - a.diff || a.profile.display_name.localeCompare(b.profile.display_name))
      .map((row, index) => ({ ...row, rank_no: index + 1 }));
    const players = state.db.tournament_players
      .filter((p) => p.tournament_id === tournamentId)
      .map((p) => ({ ...p, profile: byId(state.db.profiles, p.profile_id) }));
    return { tournament, matches, standings, players, membership: currentMembership(tournamentId) };
  }

  function addActivity(actionCode, entityId, message) {
    state.db.activity_log.unshift({
      id: Date.now(), action_code: actionCode, entity_id: entityId, actor_profile_id: state.session.profileId,
      created_at: new Date().toISOString(), payload: { message }
    });
  }

  function recalcStandings(tournamentId) {
    const players = state.db.tournament_players.filter((p) => p.tournament_id === tournamentId && p.participation_status === 'joined').map((p) => p.profile_id);
    const map = Object.fromEntries(players.map((id) => [id, { tournament_id: tournamentId, profile_id: id, played: 0, won: 0, lost: 0, points: 0, diff: 0 }]));
    const tournamentMatches = state.db.matches.filter((m) => m.tournament_id === tournamentId);
    tournamentMatches.forEach((match) => {
      const result = state.db.match_results.find((r) => r.match_id === match.id);
      if (!result) return;
      const participants = state.db.match_players.filter((mp) => mp.match_id === match.id).map((mp) => ({ ...mp, profile_id: byId(state.db.tournament_players, mp.tournament_player_id).profile_id }));
      const team1Ids = participants.filter((p) => p.team_no === 1).map((p) => p.profile_id);
      const team2Ids = participants.filter((p) => p.team_no === 2).map((p) => p.profile_id);
      const winnerTeam = result.winner_team_no;
      const loserTeam = winnerTeam === 1 ? 2 : 1;
      team1Ids.concat(team2Ids).forEach((pid) => { if (map[pid]) map[pid].played += 1; });
      (winnerTeam === 1 ? team1Ids : team2Ids).forEach((pid) => { if (map[pid]) { map[pid].won += 1; map[pid].points += 3; map[pid].diff += 1; } });
      (loserTeam === 1 ? team1Ids : team2Ids).forEach((pid) => { if (map[pid]) { map[pid].lost += 1; map[pid].diff -= 1; } });
    });
    state.db.standings_entries = state.db.standings_entries.filter((s) => s.tournament_id !== tournamentId)
      .concat(Object.values(map).map((row, index) => ({ id: `s_${tournamentId}_${row.profile_id}_${index}`, ...row, rank_no: index + 1 })));
  }

  const demoAdapter = {
    mode: 'demo',
    async getPlayerHome() { return computeHome(); },
    async getMyMatchCards() { return computeMatches(); },
    async getTournamentStandingsCurrent(tournamentId) { return computeTournament(tournamentId).standings; },
    async getTournamentBundle(tournamentId) { return computeTournament(tournamentId); },
    async rpcJoinTournament(tournamentId) {
      const tournament = byId(state.db.tournaments, tournamentId);
      if (!tournament || tournament.tournament_status !== 'open') throw new Error('Tournament is not open.');
      if (currentMembership(tournamentId)) throw new Error('Already joined.');
      state.db.tournament_players.push({ id: `tp_${Date.now()}`, tournament_id: tournamentId, profile_id: state.session.profileId, participation_status: 'joined' });
      addActivity('join', tournamentId, `Joined ${tournament.name}`);
      recalcStandings(tournamentId);
      saveDb();
      return { status: 'joined', message: 'Player joined successfully' };
    },
    async rpcWithdrawTournament(tournamentId) {
      const row = state.db.tournament_players.find((p) => p.tournament_id === tournamentId && p.profile_id === state.session.profileId && p.participation_status !== 'withdrawn');
      if (!row) throw new Error('You are not joined.');
      row.participation_status = 'withdrawn';
      addActivity('withdraw', tournamentId, `Withdrawn from ${byId(state.db.tournaments, tournamentId).name}`);
      recalcStandings(tournamentId);
      saveDb();
      return { status: 'withdrawn', message: 'Player withdrawn' };
    },
    async rpcSubmitMatchResult(matchId, scoreDisplay) {
      const match = byId(state.db.matches, matchId);
      if (!match) throw new Error('Match not found.');
      const participants = state.db.match_players.filter((mp) => mp.match_id === matchId)
        .map((mp) => byId(state.db.tournament_players, mp.tournament_player_id)?.profile_id);
      if (!participants.includes(state.session.profileId)) throw new Error('Only match participant can submit result.');
      const parsed = parseScore(scoreDisplay);
      const existing = state.db.match_results.find((r) => r.match_id === matchId);
      if (existing) Object.assign(existing, parsed, { submitted_by_profile_id: state.session.profileId, submitted_at: new Date().toISOString() });
      else state.db.match_results.push({ id: `mr_${Date.now()}`, match_id: matchId, submitted_by_profile_id: state.session.profileId, submitted_at: new Date().toISOString(), ...parsed });
      match.result_status = 'submitted';
      addActivity('submit_result', match.tournament_id, `Result submitted for ${byId(state.db.tournaments, match.tournament_id).name}`);
      recalcStandings(match.tournament_id);
      saveDb();
      return { result_status: 'submitted', submitted_at: new Date().toISOString() };
    },
    reset() {
      state.db = clone(DEMO_DB);
      saveDb();
    }
  };

  function parseScore(scoreDisplay) {
    const sets = String(scoreDisplay || '').trim().split(/\s+/).map((part) => part.split(':').map(Number)).filter((arr) => arr.length === 2 && arr.every((n) => !Number.isNaN(n)));
    let t1 = 0; let t2 = 0;
    sets.forEach(([a, b]) => { if (a > b) t1 += 1; else if (b > a) t2 += 1; });
    return {
      score_display: scoreDisplay,
      score_json: { sets: sets.map(([team1, team2]) => ({ team1, team2 })) },
      winner_team_no: t1 >= t2 ? 1 : 2
    };
  }

  async function createSupabaseAdapter() {
    if (!CONFIG.useRealSupabase || !CONFIG.supabaseUrl || !CONFIG.supabaseAnonKey) return demoAdapter;
    try {
      await loadSupabaseBrowserClient();
      const client = window.supabase.createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey);
      return {
        mode: 'supabase',
        async getPlayerHome() {
          const { data, error } = await client.from('v_player_home').select('*');
          if (error) throw error;
          return normalizePlayerHomeRows(data || []);
        },
        async getMyMatchCards() {
          const { data, error } = await client.from('v_my_match_cards').select('*');
          if (error) throw error;
          return data || [];
        },
        async getTournamentStandingsCurrent(tournamentId) {
          const { data, error } = await client.from('v_tournament_standings_current').select('*').eq('tournament_id', tournamentId).order('rank_no');
          if (error) throw error;
          return data || [];
        },
        async getTournamentBundle(tournamentId) {
          const [home, matches, standings] = await Promise.all([
            this.getPlayerHome(),
            this.getMyMatchCards(),
            this.getTournamentStandingsCurrent(tournamentId)
          ]);
          const tournament = [...home.my, ...home.available, ...home.history].find((row) => row.id === tournamentId);
          return { tournament, matches: matches.filter((m) => m.tournament_id === tournamentId), standings, players: [], membership: null };
        },
        async rpcJoinTournament(tournamentId) {
          const { data, error } = await client.rpc('rpc_join_tournament', { p_tournament_id: tournamentId });
          if (error) throw error;
          return data;
        },
        async rpcWithdrawTournament(tournamentId) {
          const { data, error } = await client.rpc('rpc_withdraw_tournament', { p_tournament_id: tournamentId });
          if (error) throw error;
          return data;
        },
        async rpcSubmitMatchResult(matchId, scoreDisplay) {
          const { data, error } = await client.rpc('rpc_submit_match_result', { p_match_id: matchId, p_score_json: parseScore(scoreDisplay).score_json });
          if (error) throw error;
          return data;
        },
        async signInWithOtp(email) {
          const { error } = await client.auth.signInWithOtp({ email });
          if (error) throw error;
        },
        async signOut() { await client.auth.signOut(); }
      };
    } catch (error) {
      showToast(`Supabase adapter failed: ${error.message}. Demo kept active.`);
      return demoAdapter;
    }
  }

  function normalizePlayerHomeRows(rows) {
    const out = { my: [], available: [], history: [] };
    rows.forEach((row) => {
      const bucket = row.bucket || (row.tournament_status === 'finished' ? 'history' : row.membership_status ? 'my' : 'available');
      if (bucket === 'my') out.my.push(row);
      else if (bucket === 'history') out.history.push(row);
      else out.available.push(row);
    });
    return out;
  }

  function loadSupabaseBrowserClient() {
    return new Promise((resolve, reject) => {
      if (window.supabase) return resolve();
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Cannot load supabase-js CDN'));
      document.head.appendChild(script);
    });
  }

  function setActiveNav() {
    document.querySelectorAll('[data-nav]').forEach((button) => button.classList.toggle('active', button.dataset.nav === state.route.view));
  }

  function renderCard(card, section) {
    const icon = section === 'my' ? '🎾' : section === 'history' ? '✓' : '＋';
    const badgeClass = card.status === 'live' ? 'live' : card.status === 'waitlist' ? 'waitlist' : card.tournament_status === 'finished' ? 'finished' : 'joined';
    const action = section === 'available'
      ? `<button class="action-btn primary" data-action="join" data-id="${card.id}">Join</button>`
      : section === 'history'
        ? `<button class="action-btn ghost" data-open-tournament="${card.id}">Open</button>`
        : `<button class="action-btn ghost" data-open-tournament="${card.id}">Open</button>`;
    return `<article class="card">
      <div class="card-top">
        <div class="main-icon">${icon}</div>
        <div style="flex:1;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
            <div>
              <h3>${esc(card.name)}</h3>
              <p>${esc(card.description || card.venue_name || '')}</p>
            </div>
            <span class="badge ${badgeClass}">${esc(card.status || card.tournament_status)}</span>
          </div>
          <div class="meta-grid">
            <div class="meta-item"><strong>Club</strong>${esc(card.club?.name || card.club_name || card.venue_name || '-')}</div>
            <div class="meta-item"><strong>Format</strong>${esc(card.format_code || '-')}</div>
            <div class="meta-item"><strong>Start</strong>${esc(formatDate(card.start_at))}</div>
            <div class="meta-item"><strong>Players</strong>${esc(card.joinedCount || card.joined_count || 0)} / ${esc(card.max_players || 0)}</div>
          </div>
          <div class="action-row">${action}</div>
        </div>
      </div>
    </article>`;
  }

  async function render() {
    setActiveNav();
    $('#adapterBadge').textContent = state.adapter.mode === 'supabase' ? 'Supabase' : 'Demo';
    $('#sessionText').textContent = `Signed in as ${currentProfile().display_name}`;

    if (state.route.view === 'home') {
      const data = await state.adapter.getPlayerHome();
      root.innerHTML = `
        <section class="hero"><div class="kicker">Player home</div><h1>Find your next tournament</h1><p>My tournaments first. Available tournaments second. No admin noise.</p></section>
        <div class="toolbar"><input id="homeSearch" class="text-input" placeholder="Search tournaments, clubs, formats" value="${esc(state.ui.homeSearch)}"></div>
        <div class="section-band"><h2>My tournaments</h2><span class="counter-chip">${data.my.length}</span></div>
        ${data.my.length ? data.my.map((c) => renderCard(c, 'my')).join('') : '<div class="empty-state">No active tournaments yet.</div>'}
        <div class="section-band"><h2>Available tournaments</h2><span class="counter-chip">${data.available.length}</span></div>
        ${data.available.length ? data.available.map((c) => renderCard(c, 'available')).join('') : '<div class="empty-state">No open tournaments.</div>'}
      `;
      return;
    }

    if (state.route.view === 'matches') {
      const matches = await state.adapter.getMyMatchCards();
      root.innerHTML = `
        <section class="hero"><div class="kicker">My matches</div><h1>Only my games</h1><p>Partner, opponents, time, court, score and who submitted the result.</p></section>
        <div class="tabs">
          ${['all','missing','submitted'].map((f) => `<button class="tab-btn ${state.ui.matchFilter === f ? 'active' : ''}" data-filter="${f}">${f}</button>`).join('')}
        </div>
        <div class="card">
          ${matches.length ? matches.map((m) => `<div class="match-row">
            <div>
              <div style="font-weight:800;">${esc(m.team1)} vs ${esc(m.team2)}</div>
              <div class="muted">${esc(m.tournament?.name || m.tournament_name || '')} · ${esc(m.court_label)} · ${esc(formatDate(m.scheduled_at))}</div>
              <div class="muted">Submitted by: ${esc(m.submittedBy || m.submitted_by_name || '—')}</div>
            </div>
            <div style="text-align:right;">
              <div class="score-pill">${esc(m.score || m.score_display || 'Pending')}</div>
              <div class="action-row" style="justify-content:flex-end; margin-top:8px;"><button class="action-btn ghost" data-open-sheet="result" data-id="${m.id}">Submit</button></div>
            </div>
          </div>`).join('') : '<div class="empty-state">No matches in current filter.</div>'}
        </div>
      `;
      return;
    }

    if (state.route.view === 'history') {
      const data = await state.adapter.getPlayerHome();
      root.innerHTML = `
        <section class="hero"><div class="kicker">History</div><h1>Finished tournaments</h1><p>Old events leave the home screen and live here.</p></section>
        ${data.history.length ? data.history.map((c) => renderCard(c, 'history')).join('') : '<div class="empty-state">No finished tournaments yet.</div>'}
      `;
      return;
    }

    if (state.route.view === 'profile') {
      const profile = currentProfile();
      root.innerHTML = `
        <section class="hero"><div class="kicker">Profile</div><h1>${esc(profile.display_name)}</h1><p>${esc(profile.city)} · level ${esc(profile.level)}</p></section>
        <article class="card">
          <div class="card-top"><div class="main-icon">${initials(profile.display_name)}</div><div><h3>Account</h3><p>v6 is ready for Supabase auth shell, but still safe to demo on GitHub Pages.</p></div></div>
          <div class="meta-grid">
            <div class="meta-item"><strong>Role</strong>${esc(profile.role)}</div>
            <div class="meta-item"><strong>Email</strong>${esc(state.session.email)}</div>
          </div>
          <div class="action-row"><button class="action-btn ghost" data-open-sheet="auth">Auth shell</button><button class="action-btn ghost" data-open-sheet="contract">Contract</button></div>
        </article>
        <article class="card">
          <h3 style="margin-bottom:12px;">Recent activity</h3>
          ${state.db.activity_log.slice(0, 8).map((a) => `<div class="activity-row"><div><div style="font-weight:700;">${esc(a.payload.message)}</div><div class="muted">${esc(a.action_code)} · ${esc(formatDate(a.created_at))}</div></div></div>`).join('')}
        </article>
      `;
      return;
    }

    if (state.route.view === 'tournament') {
      const bundle = await state.adapter.getTournamentBundle(state.route.tournamentId);
      const t = bundle.tournament;
      if (!t) {
        pushRoute({ view: 'home', tournamentId: null, tab: 'overview' });
        return render();
      }
      root.innerHTML = `
        <section class="hero"><div class="kicker">Tournament detail</div><h1>${esc(t.name)}</h1><p>${esc(t.venue_name || t.club?.name || '')} · ${esc(t.format_code || '')}</p></section>
        <div class="tabs">
          ${['overview','matches','standings','players'].map((tab) => `<button class="tab-btn ${state.route.tab === tab ? 'active' : ''}" data-tab="${tab}">${tab}</button>`).join('')}
        </div>
        ${state.route.tab === 'overview' ? renderTournamentOverview(bundle) : ''}
        ${state.route.tab === 'matches' ? renderTournamentMatches(bundle) : ''}
        ${state.route.tab === 'standings' ? renderTournamentStandings(bundle) : ''}
        ${state.route.tab === 'players' ? renderTournamentPlayers(bundle) : ''}
      `;
    }
  }

  function renderTournamentOverview(bundle) {
    const t = bundle.tournament;
    const membership = bundle.membership;
    const actions = membership
      ? `<button class="action-btn warn" data-action="withdraw" data-id="${t.id}">Withdraw</button>`
      : t.tournament_status === 'open'
        ? `<button class="action-btn primary" data-action="join" data-id="${t.id}">Join tournament</button>`
        : '';
    return `<article class="card">
      <div class="meta-grid">
        <div class="meta-item"><strong>Status</strong>${esc(t.status || t.tournament_status)}</div>
        <div class="meta-item"><strong>Start</strong>${esc(formatDate(t.start_at))}</div>
        <div class="meta-item"><strong>Venue</strong>${esc(t.venue_name || t.club?.name || '-')}</div>
        <div class="meta-item"><strong>Capacity</strong>${esc(t.joinedCount || 0)} / ${esc(t.max_players || 0)}</div>
      </div>
      <div class="action-row">${actions}<button class="action-btn ghost" data-open-sheet="contract">View contract</button></div>
    </article>`;
  }

  function renderTournamentMatches(bundle) {
    return `<article class="card">${bundle.matches.length ? bundle.matches.map((m) => `<div class="match-row"><div><div style="font-weight:800;">${esc(m.team1)} vs ${esc(m.team2)}</div><div class="muted">${esc(m.court_label)} · ${esc(formatDate(m.scheduled_at))}</div></div><div style="text-align:right;"><div class="score-pill">${esc(m.score || 'Pending')}</div><button class="action-btn ghost" data-open-sheet="result" data-id="${m.id}" style="margin-top:8px;">Submit</button></div></div>`).join('') : '<div class="empty-state">No matches in this tournament.</div>'}</article>`;
  }

  function renderTournamentStandings(bundle) {
    return `<article class="card">${bundle.standings.length ? bundle.standings.map((row) => `<div class="player-row"><div><div style="font-weight:800;">#${row.rank_no} ${esc(row.profile?.display_name || row.player_name || row.profile_id)}</div><div class="muted">Played ${row.played} · W ${row.won} · L ${row.lost}</div></div><div style="text-align:right;"><div class="score-pill">${row.points} pts</div><div class="muted">diff ${row.diff}</div></div></div>`).join('') : '<div class="empty-state">No standings yet.</div>'}</article>`;
  }

  function renderTournamentPlayers(bundle) {
    return `<article class="card">${bundle.players.length ? bundle.players.map((row) => `<div class="player-row"><div><div style="font-weight:800;">${esc(row.profile?.display_name || row.profile_id)}</div><div class="muted">${esc(row.participation_status)}</div></div></div>`).join('') : '<div class="empty-state">No players yet.</div>'}</article>`;
  }

  function renderSheet() {
    if (!state.sheet) return sheetRoot.innerHTML = '';
    if (state.sheet.type === 'result') {
      sheetRoot.innerHTML = `<div class="sheet-backdrop" data-close-sheet><div class="sheet"><div class="row"><h3 style="margin:0;">Submit result</h3><button class="small-btn secondary" data-close-sheet>Close</button></div><label class="field-label">Score</label><form id="resultForm"><textarea name="scoreDisplay" rows="3" placeholder="6:4 4:6 10:8">6:4 6:3</textarea><div class="action-row"><button class="action-btn primary" type="submit">Save result</button></div></form></div></div>`;
      return;
    }
    if (state.sheet.type === 'auth') {
      const options = state.db.profiles.map((p) => `<option value="${p.id}" ${p.id === state.session.profileId ? 'selected' : ''}>${esc(p.display_name)}</option>`).join('');
      sheetRoot.innerHTML = `<div class="sheet-backdrop" data-close-sheet><div class="sheet"><div class="row"><h3 style="margin:0;">Auth shell</h3><button class="small-btn secondary" data-close-sheet>Close</button></div><form id="authForm"><label class="field-label">Email</label><input class="text-input" name="email" type="email" value="${esc(state.session.email)}"><label class="field-label">Profile</label><select class="select-input" name="profileId">${options}</select><div class="action-row"><button class="action-btn primary" type="submit">Save session</button></div></form><div class="code-block" style="margin-top:12px;">window.__SUPABASE_URL__\nwindow.__SUPABASE_ANON_KEY__\nwindow.__USE_REAL_SUPABASE__ = true</div></div></div>`;
      return;
    }
    sheetRoot.innerHTML = `<div class="sheet-backdrop" data-close-sheet><div class="sheet"><div class="row"><h3 style="margin:0;">Supabase contract</h3><button class="small-btn secondary" data-close-sheet>Close</button></div><div class="code-block">Views\n- v_player_home\n- v_my_match_cards\n- v_tournament_standings_current\n\nRPC\n- rpc_join_tournament(p_tournament_id uuid)\n- rpc_withdraw_tournament(p_tournament_id uuid)\n- rpc_submit_match_result(p_match_id uuid, p_score_json jsonb)</div></div></div>`;
  }

  async function handleAction(action, id) {
    try {
      if (action === 'join') showToast((await state.adapter.rpcJoinTournament(id)).message || 'Joined');
      if (action === 'withdraw') showToast((await state.adapter.rpcWithdrawTournament(id)).message || 'Withdrawn');
      await render();
    } catch (error) {
      showToast(error.message || 'Action failed');
    }
  }

  document.addEventListener('click', async (event) => {
    const target = event.target.closest('[data-nav],[data-open-tournament],[data-action],[data-tab],[data-filter],[data-open-sheet],[data-close-sheet]');
    if (!target) return;
    if (target.dataset.nav) { pushRoute({ view: target.dataset.nav, tournamentId: null, tab: 'overview' }); return render(); }
    if (target.dataset.openTournament) { pushRoute({ view: 'tournament', tournamentId: target.dataset.openTournament, tab: 'overview' }); return render(); }
    if (target.dataset.action) return handleAction(target.dataset.action, target.dataset.id);
    if (target.dataset.tab) { state.route.tab = target.dataset.tab; return render(); }
    if (target.dataset.filter) { state.ui.matchFilter = target.dataset.filter; return render(); }
    if (target.dataset.openSheet) { state.sheet = { type: target.dataset.openSheet, matchId: target.dataset.id || null }; return renderSheet(); }
    if (target.dataset.closeSheet !== undefined) { state.sheet = null; return renderSheet(); }
  });

  document.addEventListener('submit', async (event) => {
    if (event.target.id === 'resultForm') {
      event.preventDefault();
      const scoreDisplay = new FormData(event.target).get('scoreDisplay');
      try {
        await state.adapter.rpcSubmitMatchResult(state.sheet.matchId, scoreDisplay);
        state.sheet = null;
        renderSheet();
        await render();
        showToast('Result submitted');
      } catch (error) {
        showToast(error.message || 'Cannot submit result');
      }
    }
    if (event.target.id === 'authForm') {
      event.preventDefault();
      const form = new FormData(event.target);
      state.session.email = form.get('email');
      state.session.profileId = form.get('profileId');
      saveSession();
      state.sheet = null;
      renderSheet();
      await render();
      showToast('Session updated');
    }
  });

  document.addEventListener('input', (event) => {
    if (event.target.id === 'homeSearch') {
      state.ui.homeSearch = event.target.value;
      render();
    }
  });

  $('#homeBtn').addEventListener('click', async () => { pushRoute({ view: 'home', tournamentId: null, tab: 'overview' }); await render(); });
  $('#backBtn').addEventListener('click', async () => {
    if (state.history.length > 1) state.history.pop();
    state.route = clone(state.history[state.history.length - 1] || { view: 'home', tournamentId: null, tab: 'overview' });
    await render();
  });
  $('#refreshBtn').addEventListener('click', async () => { await render(); showToast('Screen refreshed'); });
  $('#authBtn').addEventListener('click', () => { state.sheet = { type: 'auth' }; renderSheet(); });
  $('#resetBtn').addEventListener('click', async () => {
    demoAdapter.reset();
    state.session = { profileId: 'profile_anna', email: 'anna@demo.test' };
    saveSession();
    state.sheet = null;
    state.history = [{ view: 'home', tournamentId: null, tab: 'overview' }];
    state.route = clone(state.history[0]);
    await render();
    showToast('Demo reset');
  });

  (async function boot() {
    state.adapter = await createSupabaseAdapter();
    await render();
  }());
}());
