window.__SUPABASE_URL__ = '';
window.__SUPABASE_ANON_KEY__ = '';
window.__USE_REAL_SUPABASE__ = false;
