Upload ONLY the contents of this folder to GitHub Pages.

Files required:
- index.html
- styles.css
- app.js
- supabase/config.local.js

If later connecting real Supabase:
1. Put URL and anon key into supabase/config.local.js
2. Set window.__USE_REAL_SUPABASE__ = true
3. Run SQL migrations from the separate supabase folder in the full package
