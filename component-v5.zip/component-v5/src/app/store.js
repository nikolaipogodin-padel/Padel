export const store = {
  route: { view: 'home', tournamentId: null, tab: 'overview' },
  ui: { homeSearch: '', homeFilter: 'all', matchFilter: 'all' },
  cache: { home: null, matches: [], standings: [], tables: {} },
  sheet: null,
  toast: ''
};
export function setRoute(patch) { store.route = { ...store.route, ...patch }; }
export function setUi(key, value) { store.ui[key] = value; }
export function setCache(key, value) { store.cache[key] = value; }
export function setSheet(value) { store.sheet = value; }
export function setToast(message) { store.toast = message; }
