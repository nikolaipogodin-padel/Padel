import { setRoute, store } from './store.js';
export function openView(view) { setRoute({ view, tournamentId: null, tab: 'overview' }); }
export function openTournament(tournamentId) { setRoute({ view: 'tournament', tournamentId, tab: 'overview' }); }
export function openTab(tab) { setRoute({ tab }); }
export function goBack() { if (store.route.view === 'tournament') openView('home'); else openView('home'); }
