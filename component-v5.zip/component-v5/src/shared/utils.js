export function clone(value) { return JSON.parse(JSON.stringify(value)); }
export function byId(list, id) { return list.find((item) => item.id === id); }
export function initials(value = '') {
  return value.split(/\s+/).filter(Boolean).slice(0,2).map((item) => item[0]?.toUpperCase() || '').join('') || 'P';
}
export function formatClock() { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
export function escapeHtml(value = '') {
  return String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}
