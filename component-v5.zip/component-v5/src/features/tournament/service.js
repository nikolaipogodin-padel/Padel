import { VIEW_NAMES } from '../../contracts/views.js';
import { RPC_NAMES } from '../../contracts/rpc.js';
import { supabaseClient } from '../../api/client.js';
export async function loadStandings(tournamentId) { return supabaseClient.view(VIEW_NAMES.TOURNAMENT_STANDINGS_CURRENT, { tournament_id: tournamentId }); }
export async function joinTournament(tournamentId) { return supabaseClient.rpc(RPC_NAMES.JOIN_TOURNAMENT, { tournament_id: tournamentId }); }
export async function withdrawTournament(tournamentId) { return supabaseClient.rpc(RPC_NAMES.WITHDRAW_TOURNAMENT, { tournament_id: tournamentId }); }
export async function submitMatchResult(matchId, scoreDisplay) { return supabaseClient.rpc(RPC_NAMES.SUBMIT_MATCH_RESULT, { match_id: matchId, score_json: { display: scoreDisplay, sets: [] } }); }
