import { VIEW_NAMES } from '../../contracts/views.js';
import { supabaseClient } from '../../api/client.js';
export async function loadMyMatches() { return supabaseClient.view(VIEW_NAMES.MY_MATCH_CARDS); }
