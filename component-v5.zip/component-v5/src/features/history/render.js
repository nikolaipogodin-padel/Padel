export function renderHistoryScreen(historyCards) {
  return `<section class="hero"><div class="eyebrow">History</div><h1>Finished Tournaments</h1><p>Finished tournaments stay out of home by product rule.</p></section>
  ${historyCards.map((item) => `<div class="card"><button class="tournament-open" data-open-tournament="${item.id}"><div class="card-head"><div><h3 class="card-title">${item.title}</h3><div class="card-subtitle">${item.subtitle}</div></div><div class="badge finished">${item.badge}</div></div><div class="meta-text" style="margin-top:14px;">${item.clubName} · ${item.startLabel}</div></button></div>`).join('')}`;
}
