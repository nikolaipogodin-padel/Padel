export function renderProfileScreen(profile, activity) {
  return `<section class="hero"><div class="eyebrow">Profile</div><h1>${profile.display_name}</h1><p>Supabase-ready demo shell with fake adapter and contract-driven screens.</p></section>
  <div class="profile-card card"><div class="kv-grid"><div class="kv-item"><div class="stat-label">City</div><div class="stat-value">${profile.city}</div></div><div class="kv-item"><div class="stat-label">Level</div><div class="stat-value">${profile.level}</div></div><div class="kv-item"><div class="stat-label">Role</div><div class="stat-value">${profile.role}</div></div><div class="kv-item"><div class="stat-label">Adapter</div><div class="stat-value">Fake Supabase</div></div></div><div class="action-row"><button class="action-btn secondary" data-reset-demo>Reset demo</button><button class="action-btn" data-open-sheet="contracts">View contracts</button></div></div>
  <div class="section-band">Recent activity</div>
  ${activity.map((item) => `<div class="activity-card card"><div class="row"><div class="card-subtitle">${item.text}</div><div class="table-note">${item.time_label}</div></div></div>`).join('')}`;
}
