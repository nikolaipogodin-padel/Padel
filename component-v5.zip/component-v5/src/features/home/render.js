import { escapeHtml } from '../../shared/utils.js';
function renderCard(card) {
  return `<div class="card"><button class="tournament-open" data-open-tournament="${card.id}">
    <div class="card-head"><div class="row"><div class="banner-icon">${escapeHtml(card.banner)}</div><div><h3 class="card-title">${escapeHtml(card.title)}</h3><div class="card-subtitle">${escapeHtml(card.subtitle)}</div></div></div><div class="badge ${card.badgeClass}">${escapeHtml(card.badge)}</div></div>
    <div class="card-stats"><div class="stat-card"><div class="stat-label">Club</div><div class="stat-value">${escapeHtml(card.clubName)}</div></div><div class="stat-card"><div class="stat-label">Start</div><div class="stat-value">${escapeHtml(card.startLabel)}</div></div><div class="stat-card"><div class="stat-label">Spots</div><div class="stat-value">${escapeHtml(card.spotsLabel)}</div></div></div>
    <div class="meta-text">${escapeHtml(card.venue)} · ${escapeHtml(card.phase)}</div></button>
    <div class="action-row" style="margin-top:14px;">${card.canJoin ? `<button class="action-btn" data-join-tournament="${card.id}">Join</button>` : ''}${card.canWithdraw ? `<button class="action-btn warn" data-withdraw-tournament="${card.id}">Withdraw</button>` : ''}<button class="action-btn secondary" data-open-tournament="${card.id}">Open</button></div>
  </div>`;
}
export function renderHomeScreen(data, ui) {
  const q = ui.homeSearch.trim().toLowerCase();
  const filterBlock = (items) => items.filter((item) => !q || `${item.title} ${item.subtitle} ${item.clubName}`.toLowerCase().includes(q));
  const my = filterBlock(data.my_tournaments || []);
  const available = filterBlock(data.available_tournaments || []);
  return `<section class="hero"><div class="eyebrow">Player Home</div><h1>My Tournaments</h1><p>Contract-driven home feed through v_player_home.</p></section>
  <div class="searchbar"><span>⌕</span><input id="homeSearchInput" value="${escapeHtml(ui.homeSearch)}" placeholder="Search tournaments or clubs" /><button class="menu-btn" data-refresh-home>Refresh</button></div>
  <div class="section-band">My tournaments</div>
  ${my.length ? my.map(renderCard).join('') : `<div class="empty-card card">Nothing active right now.</div>`}
  <div class="section-band">Available tournaments</div>
  ${available.length ? available.map(renderCard).join('') : `<div class="empty-card card">No available tournaments found.</div>`}`;
}
