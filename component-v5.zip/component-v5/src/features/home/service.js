import { VIEW_NAMES } from '../../contracts/views.js';
import { supabaseClient } from '../../api/client.js';
export async function loadHomeData() { return supabaseClient.view(VIEW_NAMES.PLAYER_HOME); }
