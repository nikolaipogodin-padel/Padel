export const seed = {
  meta: { version: 'v5', currentProfileId: 'profile_anna', sequence: 100 },
  profiles: [
    { id: 'profile_anna', display_name: 'Anna Petrova', city: 'Barcelona', level: 'Intermediate', role: 'player', bio: 'Player-first demo account for v5' },
    { id: 'profile_igor', display_name: 'Igor Belov', city: 'Barcelona', level: 'Intermediate', role: 'player' },
    { id: 'profile_kate', display_name: 'Kate Müller', city: 'Barcelona', level: 'Advanced', role: 'player' },
    { id: 'profile_luca', display_name: 'Luca Rossi', city: 'Barcelona', level: 'Intermediate', role: 'player' },
    { id: 'profile_marta', display_name: 'Marta Silva', city: 'Barcelona', level: 'Advanced', role: 'player' },
    { id: 'profile_jonas', display_name: 'Jonas Weber', city: 'Barcelona', level: 'Advanced', role: 'player' },
    { id: 'profile_sara', display_name: 'Sara Costa', city: 'Barcelona', level: 'Beginner+', role: 'player' },
    { id: 'profile_omar', display_name: 'Omar Haddad', city: 'Barcelona', level: 'Intermediate', role: 'player' }
  ],
  clubs: [
    { id: 'club_wave', name: 'Wave Club', city: 'Barcelona', country_code: 'ES' },
    { id: 'club_orbit', name: 'Orbit Padel Center', city: 'Barcelona', country_code: 'ES' },
    { id: 'club_marina', name: 'Marina Padel Hub', city: 'Barcelona', country_code: 'ES' }
  ],
  club_admins: [ { club_id: 'club_wave', profile_id: 'profile_igor', role: 'admin' } ],
  tournaments: [
    { id: 'tour_spring_open', club_id: 'club_wave', slug: 'spring-open', name: 'Spring Open', description: 'Americano • evening block • 8 players', tournament_status: 'live', format_code: 'Americano', start_label: 'Today · 19:30', registration_close_label: 'Closed', venue_name: 'Wave Club · Court zone', max_players: 8, waitlist_enabled: true, hero_stat: '2 matches', phase: 'Round 2', banner: 'SO' },
    { id: 'tour_saturday_cup', club_id: 'club_orbit', slug: 'saturday-cup', name: 'Saturday Cup', description: 'Mexicano • weekend ladder', tournament_status: 'open', format_code: 'Mexicano', start_label: 'Sat · 11:00', registration_close_label: 'Fri · 19:00', venue_name: 'Orbit Padel Center', max_players: 16, waitlist_enabled: true, hero_stat: '3 days left', phase: 'Registration', banner: 'SC' },
    { id: 'tour_night_series', club_id: 'club_marina', slug: 'night-series', name: 'Night Series', description: 'Open ladder • social + ranking points', tournament_status: 'open', format_code: 'Ladder', start_label: 'Tue · 20:00', registration_close_label: 'Mon · 22:00', venue_name: 'Marina Padel Hub', max_players: 12, waitlist_enabled: true, hero_stat: '8 spots', phase: 'Registration', banner: 'NS' },
    { id: 'tour_club_challenge', club_id: 'club_wave', slug: 'club-challenge', name: 'Club Challenge', description: 'Group stage + playoff', tournament_status: 'open', format_code: 'Groups', start_label: 'Sun · 10:00', registration_close_label: 'Sat · 18:00', venue_name: 'Wave Club', max_players: 8, waitlist_enabled: false, hero_stat: '2 spots', phase: 'Registration', banner: 'CC' },
    { id: 'tour_winter_finals', club_id: 'club_wave', slug: 'winter-finals', name: 'Winter Finals', description: 'Completed event', tournament_status: 'finished', format_code: 'Americano', start_label: 'Mar 02', registration_close_label: 'Closed', venue_name: 'Wave Club', max_players: 8, waitlist_enabled: false, hero_stat: 'Finished', phase: 'Archived', banner: 'WF' }
  ],
  tournament_players: [
    { id: 'tp1', tournament_id: 'tour_spring_open', profile_id: 'profile_anna', participation_status: 'joined', joined_at: '2026-04-01T10:00:00Z' },
    { id: 'tp2', tournament_id: 'tour_spring_open', profile_id: 'profile_igor', participation_status: 'joined', joined_at: '2026-04-01T10:02:00Z' },
    { id: 'tp3', tournament_id: 'tour_spring_open', profile_id: 'profile_kate', participation_status: 'joined', joined_at: '2026-04-01T10:03:00Z' },
    { id: 'tp4', tournament_id: 'tour_spring_open', profile_id: 'profile_luca', participation_status: 'joined', joined_at: '2026-04-01T10:04:00Z' },
    { id: 'tp5', tournament_id: 'tour_saturday_cup', profile_id: 'profile_anna', participation_status: 'joined', joined_at: '2026-03-31T10:00:00Z' },
    { id: 'tp6', tournament_id: 'tour_saturday_cup', profile_id: 'profile_marta', participation_status: 'joined', joined_at: '2026-03-31T10:01:00Z' },
    { id: 'tp7', tournament_id: 'tour_saturday_cup', profile_id: 'profile_jonas', participation_status: 'joined', joined_at: '2026-03-31T10:02:00Z' },
    { id: 'tp8', tournament_id: 'tour_saturday_cup', profile_id: 'profile_sara', participation_status: 'joined', joined_at: '2026-03-31T10:03:00Z' },
    { id: 'tp9', tournament_id: 'tour_night_series', profile_id: 'profile_omar', participation_status: 'joined', joined_at: '2026-03-31T10:04:00Z' },
    { id: 'tp10', tournament_id: 'tour_night_series', profile_id: 'profile_sara', participation_status: 'joined', joined_at: '2026-03-31T10:05:00Z' },
    { id: 'tp11', tournament_id: 'tour_club_challenge', profile_id: 'profile_marta', participation_status: 'joined', joined_at: '2026-03-31T10:06:00Z' },
    { id: 'tp12', tournament_id: 'tour_club_challenge', profile_id: 'profile_jonas', participation_status: 'joined', joined_at: '2026-03-31T10:07:00Z' },
    { id: 'tp13', tournament_id: 'tour_club_challenge', profile_id: 'profile_igor', participation_status: 'joined', joined_at: '2026-03-31T10:08:00Z' },
    { id: 'tp14', tournament_id: 'tour_club_challenge', profile_id: 'profile_kate', participation_status: 'joined', joined_at: '2026-03-31T10:09:00Z' },
    { id: 'tp15', tournament_id: 'tour_winter_finals', profile_id: 'profile_anna', participation_status: 'joined', joined_at: '2026-02-25T10:00:00Z' },
    { id: 'tp16', tournament_id: 'tour_winter_finals', profile_id: 'profile_marta', participation_status: 'joined', joined_at: '2026-02-25T10:01:00Z' },
    { id: 'tp17', tournament_id: 'tour_winter_finals', profile_id: 'profile_luca', participation_status: 'joined', joined_at: '2026-02-25T10:02:00Z' },
    { id: 'tp18', tournament_id: 'tour_winter_finals', profile_id: 'profile_sara', participation_status: 'joined', joined_at: '2026-02-25T10:03:00Z' }
  ],
  matches: [
    { id: 'm1', tournament_id: 'tour_spring_open', round_no: 1, match_no: 1, court_label: 'Court 2', scheduled_label: 'Today · 19:30', match_status: 'completed', result_status: 'submitted' },
    { id: 'm2', tournament_id: 'tour_spring_open', round_no: 2, match_no: 2, court_label: 'Court 1', scheduled_label: 'Today · 20:10', match_status: 'scheduled', result_status: 'missing' },
    { id: 'm3', tournament_id: 'tour_saturday_cup', round_no: 1, match_no: 1, court_label: 'Court 4', scheduled_label: 'Sat · 11:20', match_status: 'scheduled', result_status: 'missing' },
    { id: 'm4', tournament_id: 'tour_winter_finals', round_no: 1, match_no: 1, court_label: 'Court 3', scheduled_label: 'Mar 02 · 18:20', match_status: 'completed', result_status: 'submitted' }
  ],
  match_players: [
    { id: 'mp1', match_id: 'm1', profile_id: 'profile_anna', seat_no: 1, team_no: 1 }, { id: 'mp2', match_id: 'm1', profile_id: 'profile_igor', seat_no: 2, team_no: 1 }, { id: 'mp3', match_id: 'm1', profile_id: 'profile_kate', seat_no: 3, team_no: 2 }, { id: 'mp4', match_id: 'm1', profile_id: 'profile_luca', seat_no: 4, team_no: 2 },
    { id: 'mp5', match_id: 'm2', profile_id: 'profile_anna', seat_no: 1, team_no: 1 }, { id: 'mp6', match_id: 'm2', profile_id: 'profile_marta', seat_no: 2, team_no: 1 }, { id: 'mp7', match_id: 'm2', profile_id: 'profile_jonas', seat_no: 3, team_no: 2 }, { id: 'mp8', match_id: 'm2', profile_id: 'profile_omar', seat_no: 4, team_no: 2 },
    { id: 'mp9', match_id: 'm3', profile_id: 'profile_anna', seat_no: 1, team_no: 1 }, { id: 'mp10', match_id: 'm3', profile_id: 'profile_marta', seat_no: 2, team_no: 1 }, { id: 'mp11', match_id: 'm3', profile_id: 'profile_jonas', seat_no: 3, team_no: 2 }, { id: 'mp12', match_id: 'm3', profile_id: 'profile_sara', seat_no: 4, team_no: 2 },
    { id: 'mp13', match_id: 'm4', profile_id: 'profile_anna', seat_no: 1, team_no: 1 }, { id: 'mp14', match_id: 'm4', profile_id: 'profile_marta', seat_no: 2, team_no: 1 }, { id: 'mp15', match_id: 'm4', profile_id: 'profile_luca', seat_no: 3, team_no: 2 }, { id: 'mp16', match_id: 'm4', profile_id: 'profile_sara', seat_no: 4, team_no: 2 }
  ],
  match_results: [
    { id: 'mr1', match_id: 'm1', submitted_by_profile_id: 'profile_anna', source: 'player', score_json: { display: '6:4 6:3', sets:[{team1:6, team2:4},{team1:6, team2:3}] }, submitted_at: '2026-04-02T19:55:00Z', winner_team_no: 1 },
    { id: 'mr2', match_id: 'm4', submitted_by_profile_id: 'profile_marta', source: 'player', score_json: { display: '6:2 4:6 10:7', sets:[{team1:6,team2:2},{team1:4,team2:6},{team1:10,team2:7}] }, submitted_at: '2026-03-02T18:58:00Z', winner_team_no: 1 }
  ],
  standings_entries: [
    { id: 'se1', tournament_id: 'tour_spring_open', profile_id: 'profile_anna', played: 1, won: 1, lost: 0, points: 3, diff: '+5', rank_no: 1 },
    { id: 'se2', tournament_id: 'tour_spring_open', profile_id: 'profile_igor', played: 1, won: 1, lost: 0, points: 3, diff: '+5', rank_no: 2 },
    { id: 'se3', tournament_id: 'tour_spring_open', profile_id: 'profile_kate', played: 1, won: 0, lost: 1, points: 0, diff: '-5', rank_no: 3 },
    { id: 'se4', tournament_id: 'tour_spring_open', profile_id: 'profile_luca', played: 1, won: 0, lost: 1, points: 0, diff: '-5', rank_no: 4 }
  ],
  activity_log: [
    { id: 'a1', entity_type: 'match_results', entity_id: 'mr1', action_code: 'result_submitted', actor_profile_id: 'profile_anna', text: 'You submitted result for Spring Open', time_label: '7 min ago' },
    { id: 'a2', entity_type: 'tournament_players', entity_id: 'tp5', action_code: 'join', actor_profile_id: 'profile_anna', text: 'You joined Saturday Cup', time_label: 'Yesterday' },
    { id: 'a3', entity_type: 'tournaments', entity_id: 'tour_spring_open', action_code: 'tournament_live', actor_profile_id: 'profile_igor', text: 'Spring Open is now live', time_label: 'Today' }
  ]
};
