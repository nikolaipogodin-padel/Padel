import { seed } from './seed.js';
import { VIEW_NAMES } from '../contracts/views.js';
import { RPC_NAMES } from '../contracts/rpc.js';
import { clone } from '../shared/utils.js';
import { mapTournamentCard, mapMatchCard } from './mappers.js';

const STORAGE_KEY = 'tournament-os-v5-db';

function loadDb() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return clone(seed);
    const parsed = JSON.parse(raw);
    return parsed?.meta?.version === 'v5' ? parsed : clone(seed);
  } catch {
    return clone(seed);
  }
}
function saveDb(db) { localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); }
function currentProfileId(db) { return db.meta.currentProfileId; }
function nextId(db, prefix) { db.meta.sequence += 1; return `${prefix}${db.meta.sequence}`; }
function clubAdmins(db, clubId) { return db.club_admins.filter((row) => row.club_id === clubId).map((row) => row.profile_id); }
function isMatchParticipant(db, profileId, matchId) { return db.match_players.some((row) => row.match_id === matchId && row.profile_id === profileId); }

function homeView(db) {
  const me = currentProfileId(db);
  const memberships = db.tournament_players.filter((row) => row.profile_id === me);
  const myTournamentIds = memberships.filter((row) => ['joined','waitlist'].includes(row.participation_status)).map((row) => row.tournament_id);
  const my = db.tournaments.filter((row) => myTournamentIds.includes(row.id) && row.tournament_status !== 'finished').map((row) => mapTournamentCard(db, row, me));
  const available = db.tournaments.filter((row) => row.tournament_status === 'open' && !myTournamentIds.includes(row.id)).map((row) => mapTournamentCard(db, row, me));
  const history = db.tournaments.filter((row) => row.tournament_status === 'finished').map((row) => mapTournamentCard(db, row, me));
  return { my_tournaments: my, available_tournaments: available, history_tournaments: history };
}

function myMatchCards(db) {
  const me = currentProfileId(db);
  return db.matches.filter((match) => isMatchParticipant(db, me, match.id)).map((match) => mapMatchCard(db, match, me));
}

function standingsView(db, tournamentId) {
  return db.standings_entries
    .filter((row) => row.tournament_id === tournamentId)
    .sort((a,b) => a.rank_no - b.rank_no)
    .map((row) => ({ ...row, player_name: db.profiles.find((p) => p.id === row.profile_id)?.display_name || 'Player' }));
}

function addActivity(db, payload) {
  db.activity_log.unshift({ id: nextId(db, 'a'), ...payload });
  db.activity_log = db.activity_log.slice(0, 20);
}

function recomputeStandings(db, tournamentId) {
  const participantIds = db.tournament_players.filter((row) => row.tournament_id === tournamentId && row.participation_status === 'joined').map((row) => row.profile_id);
  const base = participantIds.map((profileId) => ({ profile_id: profileId, played: 0, won: 0, lost: 0, points: 0, diff: 0 }));
  const box = new Map(base.map((row) => [row.profile_id, row]));
  const matches = db.matches.filter((row) => row.tournament_id === tournamentId);
  for (const match of matches) {
    const result = db.match_results.find((row) => row.match_id === match.id);
    if (!result) continue;
    const slots = db.match_players.filter((row) => row.match_id === match.id);
    const team1 = slots.filter((row) => row.team_no === 1).map((row) => row.profile_id);
    const team2 = slots.filter((row) => row.team_no === 2).map((row) => row.profile_id);
    for (const id of [...team1, ...team2]) box.get(id) && (box.get(id).played += 1);
    const winners = result.winner_team_no === 1 ? team1 : team2;
    const losers = result.winner_team_no === 1 ? team2 : team1;
    for (const id of winners) { if (box.get(id)) { box.get(id).won += 1; box.get(id).points += 3; box.get(id).diff += 2; } }
    for (const id of losers) { if (box.get(id)) { box.get(id).lost += 1; box.get(id).diff -= 2; } }
  }
  const rows = [...box.values()].sort((a,b) => b.points - a.points || b.diff - a.diff || a.profile_id.localeCompare(b.profile_id));
  db.standings_entries = db.standings_entries.filter((row) => row.tournament_id !== tournamentId);
  rows.forEach((row, index) => db.standings_entries.push({ id: nextId(db, 'se'), tournament_id: tournamentId, profile_id: row.profile_id, played: row.played, won: row.won, lost: row.lost, points: row.points, diff: row.diff >= 0 ? `+${row.diff}` : String(row.diff), rank_no: index + 1 }));
}

function rpcJoinTournament(db, tournamentId) {
  const tournament = db.tournaments.find((row) => row.id === tournamentId);
  if (!tournament) return { error: { message: 'Tournament not found' }, data: null };
  const me = currentProfileId(db);
  if (db.tournament_players.some((row) => row.tournament_id === tournamentId && row.profile_id === me && row.participation_status !== 'withdrawn')) {
    return { error: { message: 'Already joined' }, data: null };
  }
  const joined = db.tournament_players.filter((row) => row.tournament_id === tournamentId && row.participation_status === 'joined').length;
  const participation_status = joined < tournament.max_players ? 'joined' : (tournament.waitlist_enabled ? 'waitlist' : null);
  if (!participation_status) return { error: { message: 'Tournament is full' }, data: null };
  const id = nextId(db, 'tp');
  db.tournament_players.push({ id, tournament_id: tournamentId, profile_id: me, participation_status, joined_at: new Date().toISOString() });
  addActivity(db, { entity_type: 'tournament_players', entity_id: id, action_code: 'join', actor_profile_id: me, text: `You ${participation_status === 'waitlist' ? 'joined waitlist for' : 'joined'} ${tournament.name}`, time_label: 'now' });
  saveDb(db);
  return { data: { status: participation_status, participation_id: id, message: 'Player joined successfully' }, error: null };
}

function rpcWithdrawTournament(db, tournamentId) {
  const me = currentProfileId(db);
  const row = db.tournament_players.find((item) => item.tournament_id === tournamentId && item.profile_id === me && ['joined','waitlist'].includes(item.participation_status));
  if (!row) return { error: { message: 'Participation not found' }, data: null };
  row.participation_status = 'withdrawn';
  row.withdrawn_at = new Date().toISOString();
  const tournament = db.tournaments.find((item) => item.id === tournamentId);
  addActivity(db, { entity_type: 'tournament_players', entity_id: row.id, action_code: 'withdraw', actor_profile_id: me, text: `You withdrew from ${tournament?.name || 'tournament'}`, time_label: 'now' });
  saveDb(db);
  return { data: { status: 'withdrawn', participation_id: row.id, message: 'Withdrawn successfully' }, error: null };
}

function detectWinner(scoreDisplay) {
  const digits = [...String(scoreDisplay).matchAll(/(\d+)\s*:\s*(\d+)/g)].map((m) => [Number(m[1]), Number(m[2])]);
  let team1Wins = 0; let team2Wins = 0;
  for (const [a,b] of digits) { if (a > b) team1Wins += 1; if (b > a) team2Wins += 1; }
  return team1Wins >= team2Wins ? 1 : 2;
}

function rpcSubmitMatchResult(db, matchId, score_json) {
  const me = currentProfileId(db);
  const match = db.matches.find((row) => row.id === matchId);
  if (!match) return { error: { message: 'Match not found' }, data: null };
  const tournament = db.tournaments.find((row) => row.id === match.tournament_id);
  const allowed = isMatchParticipant(db, me, matchId) || clubAdmins(db, tournament.club_id).includes(me);
  if (!allowed) return { error: { message: 'User cannot submit this result' }, data: null };
  const winner_team_no = detectWinner(score_json.display || '6:4 6:4');
  let result = db.match_results.find((row) => row.match_id === matchId);
  if (!result) {
    result = { id: nextId(db, 'mr'), match_id: matchId, submitted_by_profile_id: me, source: 'player', score_json, submitted_at: new Date().toISOString(), winner_team_no };
    db.match_results.push(result);
  } else {
    result.score_json = score_json;
    result.submitted_by_profile_id = me;
    result.submitted_at = new Date().toISOString();
    result.winner_team_no = winner_team_no;
  }
  match.result_status = 'submitted';
  match.match_status = 'completed';
  recomputeStandings(db, match.tournament_id);
  addActivity(db, { entity_type: 'match_results', entity_id: result.id, action_code: 'result_submitted', actor_profile_id: me, text: `Result submitted for ${tournament.name}`, time_label: 'now' });
  saveDb(db);
  return { data: { match_id: matchId, result_status: 'submitted', submitted_by: me, submitted_at: result.submitted_at }, error: null };
}

export class FakeSupabase {
  constructor() { this.db = loadDb(); }
  refresh() { this.db = loadDb(); }
  reset() { localStorage.removeItem(STORAGE_KEY); this.db = loadDb(); }
  async view(name, params = {}) {
    this.refresh();
    if (name === VIEW_NAMES.PLAYER_HOME) return { data: homeView(this.db), error: null };
    if (name === VIEW_NAMES.MY_MATCH_CARDS) return { data: myMatchCards(this.db), error: null };
    if (name === VIEW_NAMES.TOURNAMENT_STANDINGS_CURRENT) return { data: standingsView(this.db, params.tournament_id), error: null };
    return { data: null, error: { message: `Unknown view: ${name}` } };
  }
  async rpc(name, payload = {}) {
    this.refresh();
    if (name === RPC_NAMES.JOIN_TOURNAMENT) return rpcJoinTournament(this.db, payload.tournament_id);
    if (name === RPC_NAMES.WITHDRAW_TOURNAMENT) return rpcWithdrawTournament(this.db, payload.tournament_id);
    if (name === RPC_NAMES.SUBMIT_MATCH_RESULT) return rpcSubmitMatchResult(this.db, payload.match_id, payload.score_json || { display: '6:4 6:4', sets: [] });
    return { data: null, error: { message: `Unknown rpc: ${name}` } };
  }
  async table(name) { this.refresh(); return { data: clone(this.db[name] || []), error: null }; }
}
