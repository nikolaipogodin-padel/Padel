import { FakeSupabase } from './fakeSupabase.js';
export const supabaseClient = new FakeSupabase();
