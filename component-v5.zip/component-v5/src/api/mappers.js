import { byId, initials } from '../shared/utils.js';

export function mapTournamentCard(db, tournament, currentProfileId) {
  const club = byId(db.clubs, tournament.club_id);
  const membership = db.tournament_players.find((row) => row.tournament_id === tournament.id && row.profile_id === currentProfileId);
  const joinedCount = db.tournament_players.filter((row) => row.tournament_id === tournament.id && row.participation_status === 'joined').length;
  return {
    id: tournament.id,
    title: tournament.name,
    subtitle: tournament.description,
    badge: membership ? membership.participation_status.toUpperCase() : tournament.tournament_status.toUpperCase(),
    badgeClass: membership ? membership.participation_status : tournament.tournament_status,
    banner: tournament.banner || initials(tournament.name),
    venue: tournament.venue_name,
    clubName: club?.name || 'Club',
    startLabel: tournament.start_label,
    phase: tournament.phase,
    spotsLabel: `${joinedCount}/${tournament.max_players} players`,
    canJoin: !membership && tournament.tournament_status === 'open',
    canWithdraw: !!membership && membership.participation_status === 'joined' && tournament.tournament_status !== 'finished',
    status: tournament.tournament_status
  };
}

export function mapMatchCard(db, match, currentProfileId) {
  const tournament = byId(db.tournaments, match.tournament_id);
  const slots = db.match_players.filter((row) => row.match_id === match.id).sort((a,b) => a.seat_no - b.seat_no);
  const byProfile = (profileId) => byId(db.profiles, profileId)?.display_name || 'Player';
  const team1 = slots.filter((row) => row.team_no === 1).map((row) => byProfile(row.profile_id));
  const team2 = slots.filter((row) => row.team_no === 2).map((row) => byProfile(row.profile_id));
  const mine = slots.find((row) => row.profile_id === currentProfileId);
  const result = db.match_results.find((row) => row.match_id === match.id);
  return {
    id: match.id,
    tournamentId: tournament?.id,
    tournamentName: tournament?.name || 'Tournament',
    roundLabel: `Round ${match.round_no}`,
    courtLabel: match.court_label,
    scheduledLabel: match.scheduled_label,
    status: match.result_status,
    statusClass: match.result_status,
    scoreDisplay: result?.score_json?.display || 'Missing result',
    canSubmit: !!mine,
    teamsDisplay: `${team1.join(' + ')}  vs  ${team2.join(' + ')}`
  };
}
