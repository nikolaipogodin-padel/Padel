import { supabaseClient } from './api/client.js';
import { store, setCache, setRoute, setSheet, setToast, setUi } from './app/store.js';
import { goBack, openTab, openTournament, openView } from './app/router.js';
import { loadHomeData } from './features/home/service.js';
import { loadMyMatches } from './features/matches/service.js';
import { joinTournament, loadStandings, submitMatchResult, withdrawTournament } from './features/tournament/service.js';
import { renderHomeScreen } from './features/home/render.js';
import { renderMatchesScreen } from './features/matches/render.js';
import { renderHistoryScreen } from './features/history/render.js';
import { renderProfileScreen } from './features/profile/render.js';
import { renderTournamentScreen } from './features/tournament/render.js';
import { byId, escapeHtml, formatClock } from './shared/utils.js';
import { mapTournamentCard, mapMatchCard } from './api/mappers.js';

const $ = (selector) => document.querySelector(selector);

function toast(message) {
  setToast(message);
  $('#toastRoot').innerHTML = `<div class="toast">${escapeHtml(message)}</div>`;
  window.clearTimeout(toast._t);
  toast._t = window.setTimeout(() => { $('#toastRoot').innerHTML = ''; }, 2200);
}

async function refreshCache() {
  const home = await loadHomeData();
  const matches = await loadMyMatches();
  setCache('home', home.data);
  setCache('matches', matches.data || []);
  const tables = await Promise.all(['profiles','tournaments','tournament_players','matches','activity_log'].map((name) => supabaseClient.table(name).then((res) => [name, res.data])));
  setCache('tables', Object.fromEntries(tables));
  if (store.route.tournamentId) {
    const standings = await loadStandings(store.route.tournamentId);
    setCache('standings', standings.data || []);
  }
}

function setActiveNav() {
  document.querySelectorAll('[data-nav]').forEach((node) => node.classList.toggle('active', node.dataset.nav === store.route.view));
}

function currentProfile() {
  return byId(supabaseClient.db?.profiles || [], supabaseClient.db?.meta?.currentProfileId) || { display_name: 'Player', city: '-', level: '-', role: 'player' };
}

function renderSheet() {
  if (!store.sheet) { $('#sheetRoot').innerHTML = ''; return; }
  if (store.sheet.type === 'submit-result') {
    $('#sheetRoot').innerHTML = `<div class="sheet-backdrop" data-close-sheet><div class="sheet" onclick="event.stopPropagation()"><div class="row"><h3 style="margin:0;">Submit result</h3><button class="small-btn" data-close-sheet>Close</button></div><p class="muted">This calls rpc_submit_match_result.</p><form data-form-result="${store.sheet.matchId}"><textarea name="scoreDisplay" placeholder="Example: 6:4 4:6 10:8">6:4 6:3</textarea><div class="action-row" style="margin-top:12px;"><button class="action-btn" type="submit">Save result</button></div></form></div></div>`;
    return;
  }
  const contractText = `Views
- v_player_home
- v_my_match_cards
- v_tournament_standings_current

RPC
- rpc_join_tournament(tournament_id)
- rpc_withdraw_tournament(tournament_id)
- rpc_submit_match_result(match_id, score_json)`;
  $('#sheetRoot').innerHTML = `<div class="sheet-backdrop" data-close-sheet><div class="sheet" onclick="event.stopPropagation()"><div class="row"><h3 style="margin:0;">Supabase contract</h3><button class="small-btn" data-close-sheet>Close</button></div><div class="code-block">${escapeHtml(contractText)}</div></div></div>`;
}

function tournamentContext() {
  const db = supabaseClient.db;
  const tournament = byId(db.tournaments, store.route.tournamentId);
  const card = mapTournamentCard(db, tournament, db.meta.currentProfileId);
  const matches = db.matches.filter((row) => row.tournament_id === tournament.id).map((row) => mapMatchCard(db, row, db.meta.currentProfileId));
  const standings = store.cache.standings;
  const players = db.tournament_players.filter((row) => row.tournament_id === tournament.id).map((row) => ({ ...row, display_name: byId(db.profiles, row.profile_id)?.display_name || 'Player' }));
  return { tournament, card, matches, standings, players, routeTab: store.route.tab };
}

function render() {
  setActiveNav();
  const home = store.cache.home || { my_tournaments: [], available_tournaments: [], history_tournaments: [] };
  let html = '';
  if (store.route.view === 'home') html = renderHomeScreen(home, store.ui);
  if (store.route.view === 'matches') html = renderMatchesScreen(store.cache.matches || [], store.ui);
  if (store.route.view === 'history') html = renderHistoryScreen(home.history_tournaments || []);
  if (store.route.view === 'profile') html = renderProfileScreen(currentProfile(), supabaseClient.db.activity_log.slice(0, 6));
  if (store.route.view === 'tournament') html = renderTournamentScreen(tournamentContext());
  $('#appRoot').innerHTML = html;
  renderSheet();
}

async function rerender() { await refreshCache(); render(); }

async function boot() {
  $('#clockText').textContent = formatClock();
  window.setInterval(() => $('#clockText').textContent = formatClock(), 60000);
  await rerender();
}

$('#backBtn').addEventListener('click', async () => { goBack(); await rerender(); });
$('#brandBtn').addEventListener('click', async () => { openView('home'); await rerender(); });
$('#syncBtn').addEventListener('click', async () => { await rerender(); toast('Cache refreshed from adapter.'); });

document.addEventListener('click', async (event) => {
  const target = event.target.closest('[data-nav],[data-open-tournament],[data-detail-tab],[data-match-filter],[data-open-sheet],[data-close-sheet],[data-reset-demo],[data-join-tournament],[data-withdraw-tournament],[data-refresh-home]');
  if (!target) return;
  if (target.dataset.nav) { openView(target.dataset.nav); return rerender(); }
  if (target.dataset.openTournament) { openTournament(target.dataset.openTournament); return rerender(); }
  if (target.dataset.detailTab) { openTab(target.dataset.detailTab); return render(); }
  if (target.dataset.matchFilter) { setUi('matchFilter', target.dataset.matchFilter); return render(); }
  if (target.dataset.openSheet) { setSheet({ type: target.dataset.openSheet, matchId: target.dataset.matchId || null }); return renderSheet(); }
  if (target.dataset.closeSheet !== undefined) { setSheet(null); return renderSheet(); }
  if (target.dataset.resetDemo !== undefined) { supabaseClient.reset(); setRoute({ view: 'home', tournamentId: null, tab: 'overview' }); await rerender(); return toast('Demo reset.'); }
  if (target.dataset.joinTournament) { const res = await joinTournament(target.dataset.joinTournament); await rerender(); return toast(res.error?.message || res.data?.message || 'Joined'); }
  if (target.dataset.withdrawTournament) { const res = await withdrawTournament(target.dataset.withdrawTournament); await rerender(); return toast(res.error?.message || res.data?.message || 'Withdrawn'); }
  if (target.dataset.refreshHome !== undefined) { await rerender(); return toast('Home feed refreshed.'); }
});

document.addEventListener('input', (event) => {
  if (event.target.id === 'homeSearchInput') { setUi('homeSearch', event.target.value); render(); }
});

document.addEventListener('submit', async (event) => {
  const form = event.target.closest('[data-form-result]');
  if (!form) return;
  event.preventDefault();
  const scoreDisplay = new FormData(form).get('scoreDisplay')?.toString().trim() || '6:4 6:3';
  const res = await submitMatchResult(form.dataset.formResult, scoreDisplay);
  setSheet(null);
  await rerender();
  toast(res.error?.message || 'Result submitted.');
});

boot();
