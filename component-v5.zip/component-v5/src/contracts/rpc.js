export const RPC_NAMES = {
  JOIN_TOURNAMENT: 'rpc_join_tournament',
  WITHDRAW_TOURNAMENT: 'rpc_withdraw_tournament',
  SUBMIT_MATCH_RESULT: 'rpc_submit_match_result'
};
