export const TABLES = {
  PROFILES: 'profiles',
  CLUBS: 'clubs',
  TOURNAMENTS: 'tournaments',
  TOURNAMENT_PLAYERS: 'tournament_players',
  MATCHES: 'matches',
  MATCH_RESULTS: 'match_results',
  STANDINGS_ENTRIES: 'standings_entries',
  ACTIVITY_LOG: 'activity_log'
};
