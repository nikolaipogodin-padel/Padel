export const VIEW_NAMES = {
  PLAYER_HOME: 'v_player_home',
  MY_MATCH_CARDS: 'v_my_match_cards',
  TOURNAMENT_STANDINGS_CURRENT: 'v_tournament_standings_current'
};
