These SQL files are skeletons only. Replace placeholder logic with real Postgres/Supabase implementation.
