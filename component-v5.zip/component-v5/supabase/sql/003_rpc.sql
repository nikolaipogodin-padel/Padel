create or replace function rpc_join_tournament(tournament_id uuid)
returns jsonb language plpgsql security definer as $$
begin
  return jsonb_build_object('status','joined','tournament_id',tournament_id);
end;
$$;

create or replace function rpc_withdraw_tournament(tournament_id uuid)
returns jsonb language plpgsql security definer as $$
begin
  return jsonb_build_object('status','withdrawn','tournament_id',tournament_id);
end;
$$;

create or replace function rpc_submit_match_result(match_id uuid, score_json jsonb)
returns jsonb language plpgsql security definer as $$
begin
  return jsonb_build_object('match_id',match_id,'result_status','submitted','score_json',score_json);
end;
$$;
