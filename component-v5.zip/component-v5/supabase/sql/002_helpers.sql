create or replace function is_club_admin(p_profile_id uuid, p_club_id uuid)
returns boolean language sql stable as $$
  select exists (
    select 1 from club_admins
    where club_id = p_club_id and profile_id = p_profile_id
  );
$$;

create or replace function is_match_participant(p_profile_id uuid, p_match_id uuid)
returns boolean language sql stable as $$
  select exists (
    select 1 from match_players
    where match_id = p_match_id and profile_id = p_profile_id
  );
$$;
