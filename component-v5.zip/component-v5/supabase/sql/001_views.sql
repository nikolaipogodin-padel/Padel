-- v5 SQL skeletons
create or replace view v_player_home as
select 'replace-with-real-sql' as note;

create or replace view v_my_match_cards as
select 'replace-with-real-sql' as note;

create or replace view v_tournament_standings_current as
select 'replace-with-real-sql' as note;
